var HashMap = Java.type("java.util.HashMap");
var map = new HashMap();
map.put("Rajasthan","Jaipur");
map.put("India","Dehli");
map.put("Punjab","Chandigarh");
map.put("Haryana","Chandigarh");
map.put("Frana","Paris");

print(map);

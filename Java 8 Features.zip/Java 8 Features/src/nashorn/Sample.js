let today = new Date();

console.log("Current Time: "+today);
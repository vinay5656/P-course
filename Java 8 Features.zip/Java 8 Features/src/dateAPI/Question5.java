package dateAPI;

import java.time.LocalTime;

public class Question5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LocalTime currentTime = LocalTime.now();
				
	    System.out.println(currentTime);
	    System.out.println(currentTime.plusMinutes(25));

	}

}

package dateAPI;

import java.time.LocalDate;

public class Question4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LocalDate today = LocalDate.now();
		System.out.println("Is 2022 is a leap year: "+today.isLeapYear());

	}

}

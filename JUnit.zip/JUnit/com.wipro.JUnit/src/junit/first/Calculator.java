package junit.first;

public class Calculator {
	public int add(int x,int y) {
		return x+y;
	}
	public int sub(int x,int y) {
		return x-y;
	}
	
	public String doStringConcat(String s1,String s2) {
		return s1+" "+s2;
	}

}

console.log("hello world");
let str1 = new String("vinay");
let str2 = new String("vinay");

let str3 = "vi";
let str4 = "vi";

console.log(str1===str2);
console.log(str1==str2);
console.log(str3===str4);
console.log(str3==str4);

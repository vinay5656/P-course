const txt = "i am vinay singh chauhan";

console.log(txt.toUpperCase());

